import numpy as np
import transformations as tf

GRAVITY = 9.81

def gravity_ft(tool_mass, tool_com, sensor_orn_q):
    tcp_rotmat = tf.quaternion_matrix(sensor_orn_q)[:3, :3]
    mg_vector = np.array([0., 0., -tool_mass * GRAVITY]).reshape(3, 1)
    f_gravity = np.matmul(np.linalg.inv(tcp_rotmat), mg_vector).reshape(-1)
    t_gravity = np.cross(tool_com, f_gravity)
    return list(f_gravity) + list(t_gravity)

def reset_bias(tool_mass, tool_com, sensor_orn_q, ft_data):
    ft_gravity = gravity_ft(tool_mass, tool_com, sensor_orn_q)
    return np.array(ft_data) - np.array(ft_gravity)

def compensation_ft(tool_mass, tool_com, bias, sensor_orn_q, ft_data):
    ft_gravity = gravity_ft(tool_mass, tool_com, sensor_orn_q)
    return np.array(ft_data) - np.array(ft_gravity) - np.array(bias)

def clear_noise(ft_data, scale):
    """ clear noise of ft sensor"""
    for i in range(6):
        if np.abs(ft_data[i]) <= scale[i]:
            ft_data[i] = 0.
        elif ft_data[i] > scale[i]:
            ft_data[i] -= scale[i]
        else:
            ft_data[i] += scale[i]
    return ft_data