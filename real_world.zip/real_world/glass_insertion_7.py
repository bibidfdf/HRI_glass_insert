import time
import numpy as np
import gym
from gym import spaces
import transformations as tf
import rtde_control
import rtde_receive
from sensor import Sensor
from common import angles2quat, quat2angles, pose_angles2pose_quat, pose_quat2pose_angles
from ft_func import reset_bias, compensation_ft, clear_noise

angle2rad = np.pi / 180.

class GlassInsertion_v7(gym.Env):

    def __init__(self):
        self.dt = 1./125.
        self.ur5_IP = '192.168.10.52'
        ati_IP = '192.168.10.54'
        self.rtde_r = rtde_receive.RTDEReceiveInterface(self.ur5_IP)
        self.rtde_c = rtde_control.RTDEControlInterface(self.ur5_IP)
        self.ati_sensor = Sensor(ati_IP)
        self.ati_sensor.send(2)
        self.ati_sensor.startStreaming()
        self.sensor2ee = tf.quaternion_matrix(tf.quaternion_from_euler(0., 0., 30.*angle2rad, 'rxyz'))

        # self.desired_ee_pose = [0.01195488590580578, -0.6959775390320184, 0.5076242111517419, -0.5, -0.5, 0.5, -0.5]
        # real install config
        # self.desired_ee_pose = [0.14660889484593698, -0.6222077699222887, 0.5668545631141431, 0.4945517177329924, 0.5077243954152427, -0.507724395415243, 0.4897453165552473]
        self.desired_ee_pose = [0.14846748983079322, -0.6257882235053119, 0.5703134083921331] + tf.quaternion_from_euler(np.pi/2., 0., -np.pi/2., 'rxyz').tolist()

        self.desired_ee_pos = self.desired_ee_pose[:3]
        self.desired_ee_orn_q = self.desired_ee_pose[3:]
        # self.desired_ee_orn_euler = tf.euler_from_quaternion(self.desired_ee_orn_q, 'rxyz')
        euler_rxyz = tf.euler_from_quaternion(self.desired_ee_orn_q, 'rxyz')
        self.desired_ee_orn_euler = [euler_rxyz[0], -euler_rxyz[2], euler_rxyz[1]]
        # print('desired_ee_orn_euler', self.desired_ee_orn_euler)

        # # without pad
        # self.tool_mass = 1.5118709650016988
        # self.tool_com = [-0.0950771873281146, -0.0923182955339260, 0.0113268631629115]

        # with pad
        self.tool_mass = 2.109209514101257
        self.tool_com = [-0.130007776834837, -0.0988737582141308, 0.00455981187529098]

        # l, w, d is glass's size, delta is the tolerance
        self.delta = 1e-3
        self.l = 0.4
        self.w = 0.2
        self.d = 0.015
        # vector of ft sensor to human-glass interaction postiion in sensor frame
        self.vector_sensor2interact = [-0.15, -0.15, 0.]

        self.insertion_duration = 6.

        self.end_euler_error = 1.*np.pi/180.

        # human dynamic parameters
        self.dh_t = 7.
        self.kh_t = 300.
        self.dh_t_matrix = self.dh_t * np.eye(3)
        self.kh_t_matrix = self.kh_t * np.eye(3)
        self.dh_r = 0.1
        self.kh_r = 3.
        self.dh_r_matrix = self.dh_r * np.eye(3)
        self.kh_r_matrix = self.kh_r * np.eye(3)

        # variable admittance control parameters
        self.md_t = 5.
        self.cd_t = 80.
        self.md_t_matrix = self.md_t * np.eye(3)
        self.cd_t_matrix = self.cd_t * np.eye(3)
        self.md_r = 0.25
        self.cd_r = 8.*2.
        self.md_r_matrix = self.md_r * np.eye(3)
        self.cd_r_matrix = self.cd_r * np.eye(3)
        self.cd_t_max = 100.
        self.cd_t_min = 50.
        self.cd_r_max = 20.
        self.cd_r_min = 10.

        # virtual F/t parameters
        self.P_t_max = 1.
        self.D_t_max = 100.
        self.P_r_max = 0.25*5e1/np.pi
        self.D_r_max = 10.
        self.con_P_t = 1.
        self.con_P_r = 0.25/np.pi

        # insertion
        self.insertion_time = 2.
        self.begin_insertion_pos_y = self.desired_ee_pose[1] + self.d - 3e-3
        self.insertion_flag = False
        self.mu = 0.5

        # UR and ATI
        # self.noise_vaue = np.array([3., 2.5, 2.5, 0.35, 0.5, 0.2]) * 1
        self.noise_vaue = np.array([0.]*6)

        # training mode
        self.real_human_flag = True 
        self.use_ft_sensor = True
        self.random_flag = False

        self.max_linear_vel = 0.05
        self.max_angular_vel = 0.2
        self.max_linear_acc = 0.1
        self.max_angular_acc = 0.2
        
        self.b_t = -np.log(self.cd_t_min/self.cd_t_max) / self.max_linear_vel
        self.b_r = -np.log(self.cd_r_min/self.cd_r_max) / self.max_angular_vel

        self.max_force = 80.
        self.max_torque = 8.

        self.act_dim = 4
        self.action_space = spaces.Box(low=np.array([-1.]*self.act_dim), high=np.array([1.]*self.act_dim), dtype=np.float32)
        low_obs = np.array([-np.inf]*14)
        high_obs = np.array([np.inf]*14)
        self.observation_space = spaces.Box(low=low_obs, high=high_obs, dtype=np.float32)

        self.a_controller_scaled = np.zeros((self.act_dim, ))

        self.omega_1 = 0.04
        self.omega_2 = 0.04
        self.omega_3 = 1.

        self.fail_type_list = ['Large force', 'Large torque', 'Large F/t', 'Time out']

    def reset(self):
        self.rtde_c.speedStop(10)
        self.t = 0.
        self.fail_type = 'None'
        self.human_force_world = np.array([0.]*3)
        self.human_torque_world = np.array([0.]*3)
        self.last_ee_vel = np.array([0.]*6)
        
        # ee_pose = self.rtde_r.getTargetTCPPose()
        # ee_pose[1] += 0.02
        # self.rtde_c.moveL(ee_pose, 0.05, 0.1)
        # time.sleep(1.)
        
        # home_joint = [90.*angle2rad, -90.*angle2rad, 90.*angle2rad, -180.*angle2rad, -90.*angle2rad, 120.*angle2rad]
        # home_joint = [90.*angle2rad, -90.*angle2rad, 90.*angle2rad, -180.*angle2rad, -90.*angle2rad, 90.*angle2rad]
        home_joint = [1.5709859005109197, -1.6784512616270284, 2.2071388289108085, -3.670231807866271, -1.577870572089699, 1.5679574359124357]
        self.rtde_c.moveJ(home_joint, 0.5, 1., False)
        time.sleep(5.)
        self.home_pose = pose_angles2pose_quat(self.rtde_r.getTargetTCPPose())

        # print('home_pose', self.home_pose)
        # time.sleep(10.)

        # test_pose = [0.14660889484593698-0.001, -0.6022077699222887, 0.5668545631141431+0.001] + tf.quaternion_from_euler(np.pi/2., 0., -1.6069379777429106 + 0.0015, 'rxyz').tolist()
        # self.rtde_c.moveL(pose_quat2pose_angles(test_pose), 0.05, 0.03)
        # time.sleep(1.)
        # cur_joint_pos = self.rtde_r.getTargetQ()
        # print('cur_joint_pos', cur_joint_pos)
        # time.sleep(10.)

        if self.random_flag:
            self.initial_ee_pos = np.array(self.home_pose[:3]) + np.random.normal(0., 0.05, size=(3,))
        else:
            self.initial_ee_pos = np.array(self.home_pose[:3])
        # self.initial_ee_pos[2] = self.home_pose[2]
        self.initial_ee_orn_q = self.home_pose[3:]

        # self.initial_ee_orn_euler = tf.euler_from_quaternion(self.home_pose[3:], 'rxyz')
        # No idea about eluer rotation axis, but this solution works
        euler_rxyz = tf.euler_from_quaternion(self.home_pose[3:], 'rxyz')
        self.initial_ee_orn_euler = [euler_rxyz[0], -euler_rxyz[2], euler_rxyz[1]]
        # print('initial_ee_orn_euler', self.initial_ee_orn_euler)

        self.p_error_max = np.abs(np.array(self.desired_ee_pose[:3]) - self.initial_ee_pos)
        self.euler_error_max = np.abs(self.desired_ee_orn_euler[1] - self.initial_ee_orn_euler[1])

        # self.rtde_c.moveL(np.array(self.initial_ee_pos).tolist()+quat2angles(self.initial_ee_orn_q), 1, 0.5, False)
        # time.sleep(1.)

        self.insertion_finished_flag = False
        self.end_flag = False
        self.rotation_flag = True

        self.cur_ee_pose = pose_angles2pose_quat(self.rtde_r.getTargetTCPPose())
        self.cur_ee_pos = self.cur_ee_pose[:3]
        self.cur_ee_orn_q = self.cur_ee_pose[3:]
        # self.cur_ee_orn_euler = tf.euler_from_quaternion(self.cur_ee_orn_q, 'rxyz')
        euler_rxyz = tf.euler_from_quaternion(self.cur_ee_orn_q, 'rxyz')
        self.cur_ee_orn_euler = [euler_rxyz[0], -euler_rxyz[2], euler_rxyz[1]]
        # print('cur_ee_orn_euler', self.cur_ee_orn_euler)
        # print(self.cur_ee_pose)
        self.cur_ee_vel = self.rtde_r.getTargetTCPSpeed()
        self.cur_ee_linear_vel = self.cur_ee_vel[:3]
        self.cur_ee_angular_vel = self.cur_ee_vel[3:]
        cur_ee2world = tf.quaternion_matrix(self.cur_ee_pose[3:])
        cur_sensor2world = np.matmul(cur_ee2world, self.sensor2ee)
        cur_sensor_orn_q = tf.quaternion_from_matrix(cur_sensor2world)

        cur_ft2sensor = self.ati_sensor.receive()
        for i in range(6):
            cur_ft2sensor[i] = cur_ft2sensor[i] / 1e6
        self.bias = reset_bias(self.tool_mass, self.tool_com, cur_sensor_orn_q, cur_ft2sensor)
        cur_ft2sensor_compensated = compensation_ft(self.tool_mass, self.tool_com, self.bias, cur_sensor_orn_q, cur_ft2sensor)

        self.cur_f2world = np.matmul(cur_sensor2world[:3, :3], cur_ft2sensor_compensated[:3].reshape(3,1)).reshape(-1)
        self.cur_t2world = np.matmul(cur_sensor2world[:3, :3], cur_ft2sensor_compensated[3:].reshape(3,1)).reshape(-1)
        self.cur_ft2world = self.cur_f2world.tolist() + self.cur_t2world.tolist()
        self.cur_ft2world = clear_noise(self.cur_ft2world, self.noise_vaue)

        if not self.use_ft_sensor:
            self.cur_ft2world = [0.] * 6

        state = self.cur_ee_pose[:3] + [self.cur_ee_orn_euler[1]] + self.cur_ee_vel[:3] + [self.cur_ee_vel[4]] + self.cur_ft2world
        return np.array(state)

    def step(self, action_scaled):
        state = self.cur_ee_pose[:3] + [self.cur_ee_orn_euler[1]] + self.cur_ee_vel[:3] + [self.cur_ee_vel[4]] + self.cur_ft2world

        action = np.zeros((self.act_dim, ))
        for i in range(self.act_dim):
            if i < 3:
                action[i] = action_scaling(action_scaled[i], self.max_linear_vel, -self.max_linear_vel)
            else:
                action[i] = action_scaling(action_scaled[i], self.max_angular_vel, -self.max_angular_vel)
        action = np.clip(action, np.array([-self.max_linear_acc]*3+[-self.max_angular_acc]) * self.dt + np.array(state)[4:8], np.array([self.max_linear_acc]*3+[self.max_angular_acc]) * self.dt + np.array(state)[4:8])
        action = np.clip(action, np.array([-self.max_linear_vel]*3+[-self.max_angular_vel]), np.array([self.max_linear_vel]*3+[self.max_angular_vel]))

        pos_error = np.linalg.norm(np.array(self.cur_ee_pose[:3]) - np.array(self.desired_ee_pos[:3]))
        # if (np.linalg.norm(np.array(self.cur_ee_pose[:3]) - np.array(self.desired_ee_pos[:3])) < 2.**0.5 * self.delta and np.linalg.norm(self.cur_ee_orn_euler[1] - self.desired_ee_orn_euler[1]) < self.end_euler_error):
        if pos_error < 5. * self.delta:
            print('Insertion finished, at ' + str(self.t) + 's')
            self.insertion_finished_flag = True

        acc_t = self.var_admittance_control_t(np.array(self.cur_ft2world[:3]).reshape(3,1), np.array(self.cur_ee_vel[:3]).reshape(3,1))
        acc_r = self.var_admittance_control_r(np.array(self.cur_ft2world[3:]).reshape(3,1), np.array(self.cur_ee_vel[3:]).reshape(3,1))

        ac_pos_vel = np.array(self.cur_ee_vel[:3]) + acc_t * self.dt
        # ac_pos_vel = np.array([0.]*3)
        if self.rotation_flag:
            ac_orn_vel = self.cur_ee_angular_vel[1] + acc_r[1] * self.dt
        else:
            ac_orn_vel = 0.
        # print('ac_orn_vel', ac_orn_vel)
        # ac_pos_vel = np.clip(ac_pos_vel, -self.max_linear_vel, self.max_linear_vel)
        # ac_orn_vel = np.clip(ac_orn_vel, -self.max_angular_vel, self.max_angular_vel)

        self.ac_action = np.array(ac_pos_vel.tolist() + [ac_orn_vel])

        for i in range(self.act_dim):
            if i < 3:
                self.a_controller_scaled[i] = inv_action_scaling(ac_pos_vel[i], self.max_linear_vel, -self.max_linear_vel)
            else:
                self.a_controller_scaled[i] = inv_action_scaling(ac_orn_vel, self.max_angular_vel, -self.max_angular_vel)

        rl_pos_vel = action[:3]
        rl_orn_vel = action[3]

        if self.cur_ee_pos[1] > self.begin_insertion_pos_y and not self.insertion_flag:
            pos_vel = ac_pos_vel
        else:
            if not self.insertion_flag:
                self.reaching2insertion_pos_y = self.cur_ee_pos[1]
                self.reaching2insertion_vel_y = self.cur_ee_linear_vel[1]
                self.reaching2insertion_time = self.t
                self.insertion_flag = True
            if self.t - self.reaching2insertion_time < self.insertion_time:
                pos_vel_y = cubic_spline(self.reaching2insertion_pos_y, self.desired_ee_pos[1]+1e-3, self.reaching2insertion_vel_y, 0., self.insertion_time, self.t - self.reaching2insertion_time)
            else:
                pos_vel_y = 0.
            # pos_vel = np.array([0., pos_vel_y, 0.])
            pos_vel = self.mu * np.array([0., pos_vel_y, 0.]) + (1. - self.mu) * ac_pos_vel
        orn_vel = np.array([0.] * 3)
        orn_vel[1] = ac_orn_vel

        self.rtde_c.speedL(pos_vel.tolist()+orn_vel.tolist(), self.max_linear_acc, self.dt)
        # self.rtde_c.waitPeriod(self.dt)
        time.sleep(self.dt)
        self.t += self.dt

        self.cur_ee_pose = pose_angles2pose_quat(self.rtde_r.getTargetTCPPose())
        self.cur_ee_pos = self.cur_ee_pose[:3]
        self.cur_ee_orn_q = self.cur_ee_pose[3:]
        # self.cur_ee_orn_euler = tf.euler_from_quaternion(self.cur_ee_orn_q, 'rxyz')
        euler_rxyz = tf.euler_from_quaternion(self.cur_ee_orn_q, 'rxyz')
        self.cur_ee_orn_euler = [euler_rxyz[0], -euler_rxyz[2], euler_rxyz[1]]
        self.cur_ee_vel = self.rtde_r.getTargetTCPSpeed()
        self.cur_ee_linear_vel = self.cur_ee_vel[:3]
        self.cur_ee_angular_vel = self.cur_ee_vel[3:]
        cur_ee2world = tf.quaternion_matrix(self.cur_ee_pose[3:])
        cur_sensor2world = np.matmul(cur_ee2world, self.sensor2ee)
        cur_sensor_orn_q = tf.quaternion_from_matrix(cur_sensor2world)

        self.cur_ee_acc = (np.array(self.cur_ee_vel) - self.last_ee_vel) / self.dt
        self.last_ee_vel = np.array(self.cur_ee_vel).copy()

        cur_ft2sensor = self.ati_sensor.receive()
        for i in range(6):
            cur_ft2sensor[i] = cur_ft2sensor[i] / 1e6
        cur_ft2sensor_compensated = compensation_ft(self.tool_mass, self.tool_com, self.bias, cur_sensor_orn_q, cur_ft2sensor)
        self.cur_f2world = np.matmul(cur_sensor2world[:3, :3], cur_ft2sensor_compensated[:3].reshape(3,1)).reshape(-1)
        self.cur_t2world = np.matmul(cur_sensor2world[:3, :3], cur_ft2sensor_compensated[3:].reshape(3,1)).reshape(-1)
        self.cur_ft2world = self.cur_f2world.tolist() + self.cur_t2world.tolist()
        self.cur_ft2world = clear_noise(self.cur_ft2world, self.noise_vaue)

        if not self.real_human_flag:
            self.cur_human_intention = []
            for i in range(3):
                self.cur_human_intention.append(cubic_spline(self.initial_ee_pos[i], self.desired_ee_pos[i], 0., 0., self.insertion_duration, self.t))
            if self.rotation_flag:
                for i in range(3):
                    self.cur_human_intention.append(cubic_spline(self.initial_ee_orn_euler[i], self.desired_ee_orn_euler[i], 0., 0., self.insertion_duration, self.t))
            if self.t > self.insertion_duration:
                self.cur_human_intention[:3] = self.desired_ee_pos
                if self.rotation_flag:
                    self.cur_human_intention[3:] = self.desired_ee_orn_euler

            self.human_force_world = self.human_dynamics_t(np.array(self.cur_human_intention[:3]).reshape(3,1), np.array(self.cur_ee_pos).reshape(3,1), np.array(self.cur_ee_linear_vel).reshape(3,1))
            # self.human_force_world = np.array([0.]*3)
            # print('cur_human_intention', self.cur_human_intention[:3])
            # print('cur_ee_pos', self.cur_ee_pos[:3])
            # print('human_force_world', self.human_force_world)
            human_force_sensor = np.matmul(np.linalg.inv(cur_sensor2world[:3,:3]), self.human_force_world).reshape(-1)
            human_torque_by_force_sensor = np.cross(self.vector_sensor2interact, human_force_sensor)
            human_torque_by_force_world = np.matmul(cur_sensor2world[:3,:3], human_torque_by_force_sensor.reshape(3,1)).reshape(-1)
            # print('human_torque_by_force_world', human_torque_by_force_world)
            if self.rotation_flag:
                self.human_torque_world = self.human_dynamics_r(np.array(self.cur_human_intention[3:]).reshape(3,1), np.array(self.cur_ee_orn_euler).reshape(3,1), np.array(self.cur_ee_angular_vel).reshape(3,1)) + human_torque_by_force_world
                # print('cur_human_intention', self.cur_human_intention[3:])
                # print('cur_ee_orn_euler', self.cur_ee_orn_euler)
                # self.human_torque_world = np.array([0.]*3)
            else:
                self.human_torque_world = np.array([0.]*3)

            if self.use_ft_sensor:
                self.cur_ft2world = np.array(self.cur_ft2world)
                self.cur_ft2world[:3] += self.human_force_world
                self.cur_ft2world[3:] += self.human_torque_world
                self.cur_ft2world = self.cur_ft2world.tolist()
                # print('cur_ft2world', self.cur_ft2world)
            else:
                self.cur_ft2world = np.array(self.cur_ft2world)
                self.cur_ft2world[:3] = self.human_force_world
                self.cur_ft2world[3:] = self.human_torque_world
                self.cur_ft2world = self.cur_ft2world.tolist()

        f_mear_norm = np.linalg.norm(self.cur_ft2world[:3])
        t_mear_norm = np.linalg.norm(self.cur_ft2world[3:])
        # print(f_mear_norm)
        if ((f_mear_norm > self.max_force or t_mear_norm > self.max_torque) and not self.insertion_finished_flag or self.rtde_r.getSafetyMode() != 1):
            kappa = -10.
            if f_mear_norm > self.max_force and not t_mear_norm > self.max_torque:
                self.fail_type = self.fail_type_list[0]
                print('Too large interaction force. ')
            elif t_mear_norm > self.max_torque and not f_mear_norm > self.max_force:
                self.fail_type = self.fail_type_list[1]
                print('Too large interaction torque. ')
            else:
                self.fail_type = self.fail_type_list[2]
                print('Too large interaction f/t. ')
            self.end_flag = True
        elif self.insertion_finished_flag:
            kappa = 200.
            self.fail_type = 'None'
            self.end_flag = True
        else:
            self.fail_type = self.fail_type_list[3]
            kappa = 0.

        self.r = -self.omega_1 * f_mear_norm/self.max_force - self.omega_2 * t_mear_norm/self.max_torque + self.omega_3 * kappa

        return np.array(state), self.r, self.end_flag, {}

    def admittance_control_t(self, f_e, d_x):
        dd_x = np.matmul(np.linalg.inv(self.md_t_matrix), f_e  - np.matmul(self.cd_t_matrix, d_x))
        return dd_x.reshape(-1)

    def var_admittance_control_t(self, f_e, d_x):
        var_cd_t = np.clip(self.cd_t_max * np.exp(-self.b_t*np.abs(d_x.reshape(-1))), [self.cd_t_min]*3, [self.cd_t_max]*3)
        var_cd_t_matrix = np.diag(var_cd_t)
        p_error = np.array(self.desired_ee_pos) - np.array(self.cur_ee_pos)
        P_t = (1 - np.minimum(np.abs(p_error)/self.p_error_max, 1.)) * self.P_t_max
        D_t = (1 - np.minimum(np.abs(p_error)/self.p_error_max, 1.)) * self.D_t_max
        f_virtual = np.diag(P_t) @ p_error.reshape(3,1) - np.diag(D_t) @ d_x
        # f_virtual = self.con_P_t * p_error.reshape(3,1) - np.diag(D_t) @ d_x
        dd_x = np.matmul(np.linalg.inv(self.md_t_matrix), f_e + f_virtual - np.matmul(var_cd_t_matrix, d_x))
        return dd_x.reshape(-1)

    def admittance_control_r(self, t_e, d_theta):
        dd_theta = np.matmul(np.linalg.inv(self.md_r_matrix), t_e  - np.matmul(self.cd_r_matrix, d_theta))
        return dd_theta.reshape(-1)

    def var_admittance_control_r(self, t_e, d_theta):
        var_cd_r = np.clip(self.cd_r_max * np.exp(-self.b_r*np.abs(d_theta.reshape(-1))), [self.cd_r_min]*3, [self.cd_r_max]*3)
        var_cd_r_matrix = np.diag(var_cd_r)
        euler_error = np.array(self.desired_ee_orn_euler) - np.array(self.cur_ee_orn_euler)
        P_r = (1 - np.minimum(np.abs(euler_error)/self.euler_error_max, 1.)) * self.P_r_max
        D_r = (1 - np.minimum(np.abs(euler_error)/self.euler_error_max, 1.)) * self.D_r_max
        t_virtual = P_r @ euler_error.reshape(3,1) - np.diag(D_r) @ d_theta
        # t_virtual = self.con_P_r * euler_error.reshape(3,1) - np.diag(D_r) @ d_theta
        dd_theta = np.matmul(np.linalg.inv(self.md_r_matrix), t_e + t_virtual - np.matmul(var_cd_r_matrix, d_theta))
        return dd_theta.reshape(-1)

    def human_dynamics_t(self, x_d, x, d_x):
        h_f = -np.matmul(self.dh_t_matrix, d_x) + np.matmul(self.kh_t_matrix, x_d - x)
        return h_f.reshape(-1)

    def human_dynamics_r(self, theta_d, theta, d_theta):
        h_t = -np.matmul(self.dh_r_matrix, d_theta) + np.matmul(self.kh_r_matrix, theta_d - theta)
        return h_t.reshape(-1)

def cubic_spline(x_i, x_f, v_i, v_f, duration, t):
    #######
    #x = at^3 + bt^2 + ct + d
    #######
    d = x_i
    c = v_i
    a = 2. * (d - x_f) / duration**3 + (c + v_f) / duration**2
    b = (v_f - 3.*a*duration**2 - c) / (2.*duration)
    # x = a * t**3 + b * t**2 + c * t + d
    v = 3. * a * t**2 + 2. * b *t + c
    return v

def action_scaling(action_scaled, max_action, min_action):
    action_original = (action_scaled + 1.)*(max_action - min_action)/2. + min_action
    return action_original

def inv_action_scaling(action_ori, max_ori_action, min_ori_action):
    action_scaled = (action_ori - min_ori_action)*2./(max_ori_action - min_ori_action) - 1.
    return action_scaled

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import time

    ee_pos_x = []
    ee_pos_y = []
    ee_pos_z = []
    euler_x = []
    euler_y = []
    euler_z = []
    x_d = []
    y_d = []
    z_d = []
    euler_x_d = []
    euler_y_d = []
    euler_z_d = []
    linear_vel_x = []
    linear_vel_y = []
    linear_vel_z = []
    angular_vel_x = []
    angular_vel_y = []
    angular_vel_z = []
    f_x = []
    f_y = []
    f_z = []
    t_x = []
    t_y = []
    t_z = []
    h_x = []
    h_y = []
    h_z = []
    h_tx = []
    h_ty = []
    h_tz = []

    env = GlassInsertion_v7()
    env.reset()
    step_num = 1250
    i = 0
    while (i < step_num and not env.insertion_finished_flag):
        env.step(np.array([0.]*env.act_dim))
        ee_pos_x.append(env.cur_ee_pos[0])
        ee_pos_y.append(env.cur_ee_pos[1])
        ee_pos_z.append(env.cur_ee_pos[2])
        euler_x.append(env.cur_ee_orn_euler[0])
        euler_y.append(env.cur_ee_orn_euler[1])
        euler_z.append(env.cur_ee_orn_euler[2])
        x_d.append(env.cur_human_intention[0])
        y_d.append(env.cur_human_intention[1])
        z_d.append(env.cur_human_intention[2])
        euler_x_d.append(env.cur_human_intention[3])
        euler_y_d.append(env.cur_human_intention[4])
        euler_z_d.append(env.cur_human_intention[5])
        linear_vel_x.append(env.cur_ee_linear_vel[0])
        linear_vel_y.append(env.cur_ee_linear_vel[1])
        linear_vel_z.append(env.cur_ee_linear_vel[2])
        angular_vel_x.append(env.cur_ee_angular_vel[0])
        angular_vel_y.append(env.cur_ee_angular_vel[1])
        angular_vel_z.append(env.cur_ee_angular_vel[2])
        f_x.append(env.cur_f2world[0])
        f_y.append(env.cur_f2world[1])
        f_z.append(env.cur_f2world[2])
        t_x.append(env.cur_t2world[0])
        t_y.append(env.cur_t2world[1])
        t_z.append(env.cur_t2world[2])
        h_x.append(env.human_force_world[0])
        h_y.append(env.human_force_world[1])
        h_z.append(env.human_force_world[2])
        h_tx.append(env.human_torque_world[0])
        h_ty.append(env.human_torque_world[1])
        h_tz.append(env.human_torque_world[2])
        i += 1

    env.rtde_c.speedStop(10)
    env.rtde_c.stopScript()

    t = np.linspace(0, len(ee_pos_x)*env.dt, len(ee_pos_x))
    
    plt.figure(1)
    plt.subplot(2, 2, 1)
    plt.plot(t, ee_pos_x, '-r', label='p_x')
    plt.plot(t, ee_pos_y, '-b', label='p_y')
    plt.plot(t, ee_pos_z, '-k', label='p_z')
    plt.plot(t, x_d, '--r', label='x_d')
    plt.plot(t, y_d, '--b', label='y_d')
    plt.plot(t, z_d, '--k', label='z_d')
    plt.xlabel('Time')
    plt.ylabel('glass position')
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(t, linear_vel_x, '-r', label='v_x')
    plt.plot(t, linear_vel_y, '-b', label='v_y')
    plt.plot(t, linear_vel_z, '-k', label='v_z')
    plt.xlabel('Time')
    plt.ylabel('glass velocity')
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(t, f_x, '-r', label='f_x')
    plt.plot(t, f_y, '-b', label='f_y')
    plt.plot(t, f_z, '-k', label='f_z')
    plt.xlabel('Time')
    plt.ylabel('EE force')
    plt.legend()

    plt.subplot(2, 2, 4)
    plt.plot(t, h_x, '-r', label='h_x')
    plt.plot(t, h_y, '-b', label='h_y')
    plt.plot(t, h_z, '-k', label='h_z')
    plt.xlabel('Time')
    plt.ylabel('Human force')
    plt.legend()

    plt.figure(2)
    plt.subplot(2, 2, 1)
    plt.plot(t, euler_x, '-r', label='euler_x')
    plt.plot(t, euler_y, '-b', label='euler_y')
    plt.plot(t, euler_z, '-k', label='euler_z')
    plt.plot(t, euler_x_d, '--r', label='euler_x_d')
    plt.plot(t, euler_y_d, '--b', label='euler_y_d')
    plt.plot(t, euler_z_d, '--k', label='euler_z_d')
    plt.xlabel('Time')
    plt.ylabel('glass orientation')
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(t, angular_vel_x, '-r', label='angular_vel_x')
    plt.plot(t, angular_vel_y, '-b', label='angular_vel_y')
    plt.plot(t, angular_vel_z, '-k', label='angular_vel_z')
    plt.xlabel('Time')
    plt.ylabel('glass angular velocity')
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(t, t_x, '-r', label='t_x')
    plt.plot(t, t_y, '-b', label='t_y')
    plt.plot(t, t_z, '-k', label='t_z')
    plt.xlabel('Time')
    plt.ylabel('EE torque')
    plt.legend()

    plt.subplot(2, 2, 4)
    # plt.figure(4)
    plt.plot(t, h_tx, '-r', label='h_tx')
    plt.plot(t, h_ty, '-b', label='h_ty')
    plt.plot(t, h_tz, '-k', label='h_tz')
    plt.xlabel('Time')
    plt.ylabel('Human torque')
    plt.legend()

    plt.show()