import logging
import math
import time
import numpy as np

import sys
sys.path.append(sys.path[0])
# import transformations as transformations
import transformations as transformations

# common constants
NUM_JOINTS = 6
DEG_2_RAD = math.pi/180.0
RAD_2_DEG = 180.0/math.pi

# import logger
logging.basicConfig(format='%(asctime)s,%(msecs)d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s', datefmt='%Y-%m-%d:%H:%M:%S', level=logging.INFO)
logger = logging.getLogger(__name__)


# geometric transforms
def angles2quat(angles):
    angle_norm = np.linalg.norm(angles)
    T_mat = transformations.rotation_matrix(angle_norm, angles/angle_norm)
    return list(transformations.quaternion_from_matrix(T_mat))

# quat in format [qx, qy, qz, qw]
def quat2angles(quat):
    T_mat = transformations.quaternion_matrix(quat)
    angle, direc, _ = transformations.rotation_from_matrix(T_mat)
    return list(angle*direc)

def pose_angles2pose_quat(pose_angles):
    return pose_angles[0:3] + angles2quat(pose_angles[3:])

def pose_quat2pose_angles(pose_quat):
    return pose_quat[0:3] + quat2angles(pose_quat[3:])

def pose2matrix(pose, unit='angle'):
    if unit == 'angle':
        angle = np.linalg.norm(pose[3:])
        T_mat = transformations.rotation_matrix(angle, pose[3:]/angle)
    elif unit == 'quat':
        # print('debug: pose[3:] {}'.format(pose[3:]))
        T_mat = transformations.quaternion_matrix(pose[3:])

    T_mat[0,3] = pose[0]
    T_mat[1,3] = pose[1]
    T_mat[2,3] = pose[2]

    return T_mat

def matrix2pose(mat, unit='angle'):
    if unit == 'angle':
        pose = [0]*6
        angle, direct, _ = transformations.rotation_from_matrix(mat)
        pose[3:] = list(angle*direct)
    elif unit == 'quat':
        pose = [0]*7
        pose[3:] = list(transformations.quaternion_from_matrix(mat))

    pose[0] = mat[0,3]
    pose[1] = mat[1,3]
    pose[2] = mat[2,3]

    return pose

def angular_vel_from_q(q_new, q, dt):
    '''

    :param q_new: new quaternion [x,y,z,w]
    :param q: last quaternion [x,y,z,w]
    :param dt: time step
    :return: angular velocity [wx, wy, wz]
    '''
    T_new = transformations.quaternion_matrix(q_new)
    T = transformations.quaternion_matrix(q)
    R_new = T_new[:3, :3]
    R = T[:3, :3]
    w_tensor = np.matmul((R_new - R), np.linalg.inv(R)) / dt
    wx = w_tensor[2, 1]
    wy = w_tensor[0, 2]
    wz = w_tensor[1, 0]
    return [wx, wy, wz]

def get_tf_inv(pose_obj_ref, unit='quat'):
    T_obj_ref = pose2matrix(np.array(pose_obj_ref), unit)
    T_ref_obj = np.linalg.inv(T_obj_ref)
    return matrix2pose(T_ref_obj, unit)

# data struct
class MovementData:
    def __init__(self, id):
        self.mov_id=id
        self.current_pos = [0.0]*6
        self.current_vel = [0.0]*6
        self.current_acc = [0.0]*6
        self.target_pos = [0.0]*6
        self.target_vel = [0.0]*6
        self.min_sync_time = 0.0 # in rml, min_sync_time <= time_reach_target_pos_and_vel; if min_sync_time is larger than required, then motion will be less greedy and take time of min_sync; Otherwise, if required time is larger than given min_sync, required time is taken to ensure reach target


if __name__ == "__main__":
    logger.setLevel(logging.DEBUG)
    logger.debug('this is a debug msg')
    logger.setLevel(logging.INFO)
    logger.info('this is a info msg')
    logger.setLevel(logging.WARNING)
    logger.warning('this is a warn msg')
    logger.setLevel(logging.ERROR)
    logger.error('this is a error msg')

    pose_angles = [1,2,3, 20*DEG_2_RAD, 30*DEG_2_RAD, 40*DEG_2_RAD]
    pose_quat = pose_angles2pose_quat(pose_angles)
    print("pose_quat ", pose_quat)
    print("pose_angles ", pose_angles)
    print("pose_angles check ", pose_quat2pose_angles(pose_quat))