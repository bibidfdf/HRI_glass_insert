import pybullet as p
import pybullet_data as pd
import time
import numpy as np
from kinematics import Kinematics
import gym
from gym import spaces
import transformations as tf

pandaNumDofs = 7
ll = [-7]*pandaNumDofs
#upper limits for null space (todo: set them to proper range)
ul = [7]*pandaNumDofs
#joint ranges for null space (todo: set them to proper range)
jr = [7]*pandaNumDofs
#restposes for null space
angle2rad = np.pi / 180


class GlassInsertion(gym.Env):

    def __init__(self):
        self.dt = 1./240.
        self.g = 0. #[-9.81, 0.]
        self.ini_robot_config = [-0.8120802918224433, 1.7117461835241918, 1.3490842089772912, -2.1637789872092332, 0.24385141998571924, 2.9252367233956718, 0.2899835454873936, 0.03, 0.03]

        # board parameters, using 4 boards to construsct a square hole
        # l, w, d is glass's size, delta is the tolerance
        # b is the borad's width
        self.delta = 1e-3
        self.l = 0.4
        self.w = 0.2
        self.d = 0.01
        self.b = 0.025
        self.board_center_position = np.array([0.3, 0.6, 0.27])
        # the origin coordinate of 4 boards, relative to the center of the whole board
        self.cdn_left = [0., -(self.l+self.b+self.delta)/2., 0.]
        self.cdn_up = [0., 0., (self.w+self.b+self.delta)/2.]
        self.cdn_right = [0., (self.l+self.b+self.delta)/2., 0.]
        self.cdn_down = [0., 0., -(self.w+self.b+self.delta)/2.]

        self.handle_l = 0.05 # handle length
        self.handle_w = 0.01 # handle width

        self.insertion_duration = 6.

        self.end_qua_error = 1e-3

        self.md_t = 1.
        self.cd_t = 20.
        self.md_t_matrix = self.md_t * np.eye(3)
        self.cd_t_matrix = self.cd_t * np.eye(3)
        self.md_r = 0.25
        self.cd_r = 2.
        self.md_r_matrix = self.md_r * np.eye(3)
        self.cd_r_matrix = self.cd_r * np.eye(3)

        self.pandaEndEffectorIndex = 11
        self.pandaFtIndex = 7
        self.panda_joint_num = 9
        self.joint_list = range(self.panda_joint_num)
        self.finger_force = 140.
        self.force_list = [87., 87., 87., 87., 12., 12., 12., self.finger_force, self.finger_force]
        self.max_vel = np.array([2.175, 2.175, 2.175, 2.175, 2.61, 2.61, 2.61, 0.05, 0.05]).reshape(9, 1)
        self.kinematics = Kinematics()
        self.flags = p.URDF_ENABLE_CACHED_GRAPHICS_SHAPES
        p.connect(p.GUI)

        self.max_linear_vel = 0.05
        self.max_angular_vel = 0.075
        self.max_linear_acc = 0.4
        self.max_angular_acc = 0.2
        self.max_force = 80.
        self.max_torque = 3.

        self.act_dim = 6
        self.action_space = spaces.Box(low=np.array([-1.]*self.act_dim), high=np.array([1.]*self.act_dim), dtype=np.float32)
        low_obs = np.array([0.3, 0.2, -0.03, -1.75, -np.pi/3., -0.25] + [-self.max_linear_vel]*3 + [-self.max_angular_vel]*3 + [-self.max_force]*3 + [-self.max_torque]*3)
        high_obs = np.array([0.7, 0.6, 0.37, -1.25, np.pi/3., 0.25] + [self.max_linear_vel]*3 + [self.max_angular_vel]*3 + [self.max_force]*3 + [self.max_torque]*3)
        self.observation_space = spaces.Box(low=low_obs, high=high_obs, dtype=np.float32)

        self.a_controller_scaled = np.zeros((self.act_dim, ))

        self.rho = 1.
        self.omega_1 = 0.02
        self.omega_2 = 0.02
        self.omega_3 = 1.

        self.fail_type_list = ['Large force', 'Large torque', 'Large F/t', 'Time out']

    def reset(self):
        ######### Domain Randomization ###############
        # Human stfiness
        self.dh_t = np.random.uniform(low=5., high=10., size=None)
        self.kh_t = np.random.uniform(low=200., high=400., size=None)
        self.dh_t_matrix = self.dh_t * np.eye(3)
        self.kh_t_matrix = self.kh_t * np.eye(3)
        self.dh_r = np.random.uniform(low=0.05, high=0.15, size=None)
        self.kh_r = np.random.uniform(low=2., high=4., size=None)
        self.dh_r_matrix = self.dh_r * np.eye(3)
        self.kh_r_matrix = self.kh_r * np.eye(3)
        # Interacting position
        self.interacting_position = np.random.uniform(low=np.array([0., -self.w/2., self.l/4.]), high=np.array([0., self.w/2., self.l/2.]), size=None)
        # Glass stiffness and damping
        self.k_glass = np.random.uniform(low=1e4, high=1.5e4, size=None)
        self.d_glass = 10.

        # pybullet
        p.resetSimulation()
        p.setAdditionalSearchPath(pd.getDataPath())
        p.setTimeStep(self.dt)
        p.setGravity(0, 0, self.g)
        # p.startStateLogging(p.STATE_LOGGING_VIDEO_MP4, './test.mp4')
        self.t = 0.
        random_flag = True
        self.fail_type = 'None'

        if random_flag:
            self.ee_position = np.array([0.5, 0.4, 0.17]) + np.random.normal(0., 0.05, size=(3,))
        else:
            self.ee_position = np.array([0.5, 0.4, 0.17])
        self.ee_position[2] = 0.17
        # y_euler = np.random.normal(0., np.pi/6.)
        y_euler = np.random.normal(0., 0.)
        ini_euler = [-1.5707963267948966, y_euler, 0.0]
        self.ee_orientation = p.getQuaternionFromEuler(ini_euler)

        self.planeId = p.loadURDF("plane.urdf")
        self.panda = p.loadURDF("panda/panda.urdf", [0, 0, 0], [0, 0, 0, 1],
                                useFixedBase=True, flags=self.flags)
        self.board_1 = p.loadURDF('board_1_1mm.urdf', np.array(self.board_center_position)+np.array(self.cdn_up), [0., 0., 0., 1.], useFixedBase=True)
        self.board_2 = p.loadURDF('board_2_1mm.urdf', np.array(self.board_center_position)+np.array(self.cdn_right), [0., 0., 0., 1.], useFixedBase=True)
        self.board_3 = p.loadURDF('board_1_1mm.urdf', np.array(self.board_center_position)+np.array(self.cdn_down), [0., 0., 0., 1.], useFixedBase=True)
        self.board_4 = p.loadURDF('board_2_1mm.urdf', np.array(self.board_center_position)+np.array(self.cdn_left), [0., 0., 0., 1.], useFixedBase=True)

        index = 0
        for j in range(p.getNumJoints(self.panda)):
            p.changeDynamics(self.panda, j, linearDamping=0, angularDamping=0)
            info = p.getJointInfo(self.panda, j)
            jointName = info[1]
            jointType = info[2]
            # print(info)
            if (jointType == p.JOINT_PRISMATIC):
                p.resetJointState(self.panda, j, self.ini_robot_config[index])
                index = index + 1
            if (jointType == p.JOINT_REVOLUTE):
                p.resetJointState(self.panda, j, self.ini_robot_config[index])
                index = index + 1

        ini_joint_pos = p.calculateInverseKinematics(self.panda, self.pandaEndEffectorIndex, self.ee_position, self.ee_orientation, maxNumIterations=200)
        index = 0
        for j in range(p.getNumJoints(self.panda)):
            p.changeDynamics(self.panda, j, linearDamping=0, angularDamping=0)
            info = p.getJointInfo(self.panda, j)
            jointName = info[1]
            jointType = info[2]
            # print(info)
            if (jointType == p.JOINT_PRISMATIC):
                p.resetJointState(self.panda, j, ini_joint_pos[index])
                index = index + 1
            if (jointType == p.JOINT_REVOLUTE):
                p.resetJointState(self.panda, j, ini_joint_pos[index])
                index = index + 1

        self.cur_ee_pos, self.cur_ee_orn, _, _, _, _, self.cur_ee_linear_vel, self.cur_ee_angular_vel = p.getLinkState(self.panda, self.pandaEndEffectorIndex, computeLinkVelocity=1, computeForwardKinematics=1)
        self.handle_glass_orientation = p.getQuaternionFromEuler([0., y_euler, 0.])
        self.handle_position = np.array(self.cur_ee_pos)
        self.glass_position = np.array(self.handle_position) + np.array([-(self.handle_l+self.d)/2., (self.l-self.handle_w)/2., 0.])
        self.handle = p.loadURDF('handle.urdf', self.handle_position, self.handle_glass_orientation)
        self.glass = p.loadURDF('glass.urdf', self.glass_position, self.handle_glass_orientation)
        p.changeDynamics(self.glass, -1, contactStiffness=self.k_glass, contactDamping=self.d_glass)

        # p.addUserDebugLine([0, 0, 0], [0.2, 0, 0], [1, 0, 0], lineWidth=5,
        #                    parentObjectUniqueId=self.panda, parentLinkIndex=8)
        # p.addUserDebugLine([0, 0, 0], [0, 0.2, 0], [0, 1, 0], lineWidth=5,
        #                    parentObjectUniqueId=self.panda, parentLinkIndex=8)
        # p.addUserDebugLine([0, 0, 0], [0, 0, 0.2], [0, 0, 1], lineWidth=5,
        #                    parentObjectUniqueId=self.panda, parentLinkIndex=8)

        p.addUserDebugLine([0, 0, 0], [0.3, 0, 0], [1, 0, 0], lineWidth=5,
                           parentObjectUniqueId=self.handle)
        p.addUserDebugLine([0, 0, 0], [0, 0.3, 0], [0, 1, 0], lineWidth=5,
                           parentObjectUniqueId=self.handle)
        p.addUserDebugLine([0, 0, 0], [0, 0, 0.3], [0, 0, 1], lineWidth=5,
                           parentObjectUniqueId=self.handle)

        p.addUserDebugLine([0, 0, 0], [0.3, 0, 0], [1, 0, 0], lineWidth=5,
                           parentObjectUniqueId=self.glass)
        p.addUserDebugLine([0, 0, 0], [0, 0.3, 0], [0, 1, 0], lineWidth=5,
                           parentObjectUniqueId=self.glass)
        p.addUserDebugLine([0, 0, 0], [0, 0, 0.3], [0, 0, 1], lineWidth=5,
                           parentObjectUniqueId=self.glass)

        p.createConstraint(self.panda, self.pandaEndEffectorIndex, self.handle, -1, jointType=p.JOINT_FIXED, jointAxis=[0., 0, 0], parentFramePosition=[0, 0, 0], childFramePosition=[0, 0, 0.])

        p.createConstraint(self.handle, -1, self.glass, -1, jointType=p.JOINT_FIXED, jointAxis=[0, 0, 0], parentFramePosition=[-(self.handle_l+self.d)/2., 0., (self.l-self.handle_w)/2.], childFramePosition=[0, 0, 0.])

        p.enableJointForceTorqueSensor(self.panda, self.pandaEndEffectorIndex)

        self.desired_glass_pos = self.board_center_position
        self.desired_glass_qua = [-0.7071067811865475, 0.0, 0.0, 0.7071067811865476]
        self.desired_glass_euler = p.getEulerFromQuaternion(self.desired_glass_qua)

        self.insertion_finished_flag = False
        self.end_flag = False
        self.rotation_flag = True

        self.cur_glass_pos, self.cur_glass_qua = p.getBasePositionAndOrientation(self.glass)
        self.cur_glass_euler = p.getEulerFromQuaternion(self.cur_glass_qua)
        self.ini_glass_pos = self.cur_glass_pos
        self.ini_glass_qua = self.cur_glass_qua
        self.ini_glass_euler = p.getEulerFromQuaternion(self.ini_glass_qua)
        # print('ini_glass_pos', self.ini_glass_pos)
        # print('ini_glass_euler', self.ini_glass_euler)
        self.cur_glass_linear_vel, self.cur_glass_angular_vel = p.getBaseVelocity(self.glass)
        self.ini_ee_pos = self.cur_ee_pos
        self.ini_ee_orn = self.cur_ee_orn
        # print('ini_ee_pos', self.ini_ee_pos)
        # print('ini_ee_qua', self.ini_ee_orn)
        # print('ini_ee_euler',p.getEulerFromQuaternion(self.ini_ee_orn))
        _, _, self.cur_ee_ft, _ = p.getJointState(self.panda, self.pandaEndEffectorIndex)
        ee2world = tf.quaternion_matrix(self.cur_ee_orn)
        self.ee_f_mear = -np.array(self.cur_ee_ft)[:3] + np.random.normal(0., 1./16., size=(3,))
        self.ee_t_mear = -np.array(self.cur_ee_ft)[3:] + np.random.normal(0., 1./750., size=(3,))
        # self.ee_f_mear = -np.array(self.cur_ee_ft)[:3]
        # self.ee_t_mear = -np.array(self.cur_ee_ft)[3:]
        self.world_f_mear = np.matmul(ee2world[:3,:3], self.ee_f_mear.reshape(3,1)).reshape(-1)
        self.world_t_mear = np.matmul(ee2world[:3,:3], self.ee_t_mear.reshape(3,1)).reshape(-1)
        state = list(self.cur_ee_pos) + list(p.getEulerFromQuaternion(self.cur_ee_orn)) + list(self.cur_ee_linear_vel) + list(self.cur_ee_angular_vel) + self.world_f_mear.tolist() + self.world_t_mear.tolist()
        return np.array(state)

    def step(self, action_scaled):
        state = list(self.cur_ee_pos) + list(p.getEulerFromQuaternion(self.cur_ee_orn)) + list(self.cur_ee_linear_vel) + list(self.cur_ee_angular_vel) + self.world_f_mear.tolist() + self.world_t_mear.tolist()

        action = np.zeros((self.act_dim, ))
        for i in range(self.act_dim):
            if i < 3:
                action[i] = action_scaling(action_scaled[i], self.max_linear_vel, -self.max_linear_vel)
            else:
                action[i] = action_scaling(action_scaled[i], self.max_angular_vel, -self.max_angular_vel)
        action = np.clip(action, np.array([-self.max_linear_vel]*3+[-self.max_angular_vel]*3), np.array([self.max_linear_vel]*3+[self.max_angular_vel]*3))
        action = np.clip(action, np.array([-self.max_linear_acc]*3+[-self.max_angular_acc]*3) * self.dt + np.array(state)[6:12], np.array([self.max_linear_acc]*3+[self.max_angular_acc]*3) * self.dt + np.array(state)[6:12])

        # contacts_1 = p.getContactPoints(bodyA=self.glass, bodyB=self.board_1)
        # contacts_2 = p.getContactPoints(bodyA=self.glass, bodyB=self.board_2)
        # contacts_3 = p.getContactPoints(bodyA=self.glass, bodyB=self.board_3)
        # contacts_4 = p.getContactPoints(bodyA=self.glass, bodyB=self.board_4)
        # if len(contacts_1):
        #     print('Contact force 1, ', contacts_1[0][9])
        # if len(contacts_2):
        #     print('Contact force 2, ', contacts_2[0][9])
        # if len(contacts_3):
        #     print('Contact force 3, ', contacts_3[0][9])
        # if len(contacts_4):
        #     print('Contact force 4, ', contacts_4[0][9])

        if (np.linalg.norm(np.array(self.cur_glass_pos) - self.board_center_position) < 2.**0.5 * self.delta and np.linalg.norm(np.array(self.cur_glass_qua) - np.array(self.desired_glass_qua)) < self.end_qua_error):
            print('Insertion finished, at ' + str(self.t) + 's')
            self.insertion_finished_flag = True

        self.cur_human_intention = []
        for i in range(3):
            self.cur_human_intention.append(cubic_spline(self.ini_glass_pos[i], self.desired_glass_pos[i], 0., 0., self.insertion_duration, self.t))
        if self.rotation_flag:
            for i in range(3):
                self.cur_human_intention.append(cubic_spline(self.ini_glass_euler[i], self.desired_glass_euler[i], 0., 0., self.insertion_duration, self.t))
        if self.t > self.insertion_duration:
            self.cur_human_intention[:3] = self.desired_glass_pos
            if self.rotation_flag:
                self.cur_human_intention[3:] = self.desired_glass_euler

        self.human_force_world = self.human_dynamics_t(np.array(self.cur_human_intention[:3]).reshape(3,1), np.array(self.cur_glass_pos).reshape(3,1), np.array(self.cur_glass_linear_vel).reshape(3,1))
        # self.human_force_world = np.array([0.]*3)
        if self.rotation_flag:
            self.human_torque_world = self.human_dynamics_r(np.array(self.cur_human_intention[3:]).reshape(3,1), np.array(self.cur_glass_euler).reshape(3,1), np.array(self.cur_glass_angular_vel).reshape(3,1))
            # self.human_torque_world = np.array([0.]*3)
        else:
            self.human_torque_world = np.array([0.]*3)

        glass2world = tf.quaternion_matrix(self.cur_glass_qua)
        self.human_force_glass = np.matmul(np.linalg.inv(glass2world)[:3, :3], self.human_force_world.reshape(3,1)).reshape(-1)
        self.human_torque_glass = np.matmul(np.linalg.inv(glass2world)[:3, :3], self.human_torque_world.reshape(3,1)).reshape(-1)

        p.applyExternalForce(self.glass, -1, self.human_force_glass, self.interacting_position, flags=p.LINK_FRAME)
        p.applyExternalTorque(self.glass, -1, self.human_torque_glass, flags=p.WORLD_FRAME)
        # p.applyExternalTorque(self.glass, -1, [0.]*3, flags=p.WORLD_FRAME)

        acc_t = self.admittance_control_t(self.world_f_mear.reshape(3,1), np.array(self.cur_ee_linear_vel).reshape(3,1))
        acc_r = self.admittance_control_r(self.world_t_mear.reshape(3,1), np.array(self.cur_ee_angular_vel).reshape(3,1))
        # acc_r = self.admittance_control_r(np.array([0.]*3).reshape(3,1), np.array(self.cur_glass_angular_vel).reshape(3,1))

        ac_pos_vel = np.array(self.cur_ee_linear_vel) + acc_t * self.dt
        # pos_vel = np.array([0.]*3)
        if self.rotation_flag:
            ac_orn_vel = np.array(self.cur_ee_angular_vel) + acc_r * self.dt
        else:
            ac_orn_vel = np.array([0.]*3)
        ac_pos_vel = np.clip(ac_pos_vel, -self.max_linear_vel, self.max_linear_vel)
        ac_orn_vel = np.clip(ac_orn_vel, -self.max_angular_vel, self.max_angular_vel)

        for i in range(self.act_dim):
            if i < 3:
                self.a_controller_scaled[i] = inv_action_scaling(ac_pos_vel[i], self.max_linear_vel, -self.max_linear_vel)
            else:
                self.a_controller_scaled[i] = inv_action_scaling(ac_orn_vel[i-3], self.max_angular_vel, -self.max_angular_vel)

        rl_pos_vel = action[:3]
        rl_orn_vel = action[3:]
        pos_vel = ac_pos_vel
        orn_vel = ac_orn_vel
        joint_vel = self.kinematics.solve_vIK(self.panda, self.pandaEndEffectorIndex, pos_vel, orn_vel)
        joint_vel = np.clip(joint_vel, -self.max_vel, self.max_vel)
        self.target_vel = joint_vel[:, 0]
        p.setJointMotorControlArray(self.panda, self.joint_list, p.VELOCITY_CONTROL,targetVelocities=self.target_vel, forces=self.force_list)

        p.stepSimulation()
        time.sleep(self.dt)
        self.t += self.dt

        self.cur_glass_pos, self.cur_glass_qua = p.getBasePositionAndOrientation(self.glass)
        self.cur_glass_euler = p.getEulerFromQuaternion(self.cur_glass_qua)
        self.cur_glass_linear_vel, self.cur_glass_angular_vel = p.getBaseVelocity(self.glass)
        _, _, self.cur_ee_ft, _ = p.getJointState(self.panda, self.pandaEndEffectorIndex)
        self.cur_ee_pos, self.cur_ee_orn, _, _, _, _, self.cur_ee_linear_vel, self.cur_ee_angular_vel = p.getLinkState(self.panda, self.pandaEndEffectorIndex, computeLinkVelocity=1, computeForwardKinematics=1)
        ee2world = tf.quaternion_matrix(self.cur_ee_orn)
        self.ee_f_mear = -np.array(self.cur_ee_ft)[:3] + np.random.normal(0., 1./16., size=(3,))
        self.ee_t_mear = -np.array(self.cur_ee_ft)[3:] + np.random.normal(0., 1./750., size=(3,))
        # self.ee_f_mear = -np.array(self.cur_ee_ft)[:3]
        # self.ee_t_mear = -np.array(self.cur_ee_ft)[3:]
        self.world_f_mear = np.matmul(ee2world[:3,:3], self.ee_f_mear.reshape(3,1)).reshape(-1)
        self.world_t_mear = np.matmul(ee2world[:3,:3], self.ee_t_mear.reshape(3,1)).reshape(-1)

        f_mear_norm = np.linalg.norm(self.world_f_mear)
        t_mear_norm = np.linalg.norm(self.world_t_mear)
        # print(f_mear_norm)
        if ((f_mear_norm > self.max_force or t_mear_norm > self.max_torque) and not self.insertion_finished_flag):
            kappa = -10.
            if f_mear_norm > self.max_force and not t_mear_norm > self.max_torque:
                self.fail_type = self.fail_type_list[0]
                print('Too large interaction force. ')
            elif t_mear_norm > self.max_torque and not f_mear_norm > self.max_force:
                self.fail_type = self.fail_type_list[1]
                print('Too large interaction torque. ')
            else:
                self.fail_type = self.fail_type_list[2]
                print('Too large interaction f/t. ')
            self.end_flag = True
        elif self.insertion_finished_flag:
            kappa = 200.
            self.fail_type = 'None'
            self.end_flag = True
        else:
            self.fail_type = self.fail_type_list[3]
            kappa = 0.

        r = -self.omega_1 * f_mear_norm/self.max_force - self.omega_2 * t_mear_norm/self.max_torque + self.omega_3 * kappa

        return np.array(state), r, self.end_flag, {}

    def admittance_control_t(self, f_e, d_x):
        dd_x = np.matmul(np.linalg.inv(self.md_t_matrix), f_e  - np.matmul(self.cd_t_matrix, d_x))
        return dd_x.reshape(-1)

    def admittance_control_r(self, t_e, d_theta):
        dd_theta = np.matmul(np.linalg.inv(self.md_r_matrix), t_e  - np.matmul(self.cd_r_matrix, d_theta))
        return dd_theta.reshape(-1)

    def human_dynamics_t(self, x_d, x, d_x):
        h_f = -np.matmul(self.dh_t_matrix, d_x) + np.matmul(self.kh_t_matrix, x_d - x)
        return h_f.reshape(-1)

    def human_dynamics_r(self, theta_d, theta, d_theta):
        h_t = -np.matmul(self.dh_r_matrix, d_theta) + np.matmul(self.kh_r_matrix, theta_d - theta)
        return h_t.reshape(-1)

def cubic_spline(x_i, x_f, v_i, v_f, duration, t):
    #######
    #x = at^3 + bt^2 + ct + d
    #######
    d = x_i
    c = v_i
    a = 2. * (d - x_f) / duration**3 + (c + v_f) / duration**2
    b = (v_f - 3.*a*duration**2 - c) / (2.*duration)
    return a * t**3 + b * t**2 + c * t + d

def action_scaling(action_scaled, max_action, min_action):
    action_original = (action_scaled + 1.)*(max_action - min_action)/2. + min_action
    return action_original

def inv_action_scaling(action_ori, max_ori_action, min_ori_action):
    action_scaled = (action_ori - min_ori_action)*2./(max_ori_action - min_ori_action) - 1.
    return action_scaled

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import time

    env = GlassInsertion()
    env.reset()
    # time.sleep(1000.)
    pos_x = []
    pos_y = []
    pos_z = []
    ee_pos_x = []
    ee_pos_y = []
    ee_pos_z = []
    euler_x = []
    euler_y = []
    euler_z = []
    vel_x = []
    vel_y = []
    vel_z = []
    angular_vel_x = []
    angular_vel_y = []
    angular_vel_z = []
    f_x = []
    f_y = []
    f_z = []
    t_x = []
    t_y = []
    t_z = []
    h_x = []
    h_y = []
    h_z = []
    h_tx = []
    h_ty = []
    h_tz = []
    x_d = []
    y_d = []
    z_d = []
    euler_x_d = []
    euler_y_d = []
    euler_z_d = []
    linear_acc_x = []
    linear_acc_y = []
    linear_acc_z = []
    angular_acc_x = []
    angular_acc_y = []
    angular_acc_z = []
    step_num = 4800
    dt = 1./240.
    # for i in range(step_num):
    i = 0
    while (i < step_num and not env.end_flag):
        env.step(np.array([0.]*6))
        pos_x.append(env.cur_glass_pos[0])
        pos_y.append(env.cur_glass_pos[1])
        pos_z.append(env.cur_glass_pos[2])
        ee_pos_x.append(env.cur_ee_pos[0])
        ee_pos_y.append(env.cur_ee_pos[1])
        ee_pos_z.append(env.cur_ee_pos[2])
        euler_x.append(env.cur_glass_euler[0])
        euler_y.append(env.cur_glass_euler[1])
        euler_z.append(env.cur_glass_euler[2])
        vel_x.append(env.cur_ee_linear_vel[0])
        vel_y.append(env.cur_ee_linear_vel[1])
        vel_z.append(env.cur_ee_linear_vel[2])
        angular_vel_x.append(env.cur_ee_angular_vel[0])
        angular_vel_y.append(env.cur_ee_angular_vel[1])
        angular_vel_z.append(env.cur_ee_angular_vel[2])
        f_x.append(env.world_f_mear[0])
        f_y.append(env.world_f_mear[1])
        f_z.append(env.world_f_mear[2])
        t_x.append(env.world_t_mear[0])
        t_y.append(env.world_t_mear[1])
        t_z.append(env.world_t_mear[2])
        h_x.append(env.human_force_world[0])
        h_y.append(env.human_force_world[1])
        h_z.append(env.human_force_world[2])
        h_tx.append(env.human_torque_world[0])
        h_ty.append(env.human_torque_world[1])
        h_tz.append(env.human_torque_world[2])
        x_d.append(env.cur_human_intention[0])
        y_d.append(env.cur_human_intention[1])
        z_d.append(env.cur_human_intention[2])
        euler_x_d.append(env.cur_human_intention[3])
        euler_y_d.append(env.cur_human_intention[4])
        euler_z_d.append(env.cur_human_intention[5])
        # linear_acc_x.append(env.linear_acc[0])
        # linear_acc_y.append(env.linear_acc[1])
        # linear_acc_z.append(env.linear_acc[2])
        # angular_acc_x.append(env.angular_acc[0])
        # angular_acc_y.append(env.angular_acc[1])
        # angular_acc_z.append(env.angular_acc[2])
        i += 1
    # p.stopStateLogging()

    t = np.linspace(0, len(pos_x)*dt, len(pos_x))
    
    plt.figure(1)
    plt.subplot(2, 2, 1)
    plt.plot(t, pos_x, '-r', label='p_x')
    plt.plot(t, pos_y, '-b', label='p_y')
    plt.plot(t, pos_z, '-k', label='p_z')
    plt.plot(t, x_d, '--r', label='x_d')
    plt.plot(t, y_d, '--b', label='y_d')
    plt.plot(t, z_d, '--k', label='z_d')
    plt.xlabel('Time')
    plt.ylabel('glass position')
    plt.legend()

    plt.subplot(2, 2, 2)
    # plt.figure(2)
    plt.plot(t, vel_x, '-r', label='v_x')
    plt.plot(t, vel_y, '-b', label='v_y')
    plt.plot(t, vel_z, '-k', label='v_z')
    plt.xlabel('Time')
    plt.ylabel('glass velocity')
    plt.legend()

    plt.subplot(2, 2, 3)
    # plt.figure(3)
    plt.plot(t, f_x, '-r', label='f_x')
    plt.plot(t, f_y, '-b', label='f_y')
    plt.plot(t, f_z, '-k', label='f_z')
    plt.xlabel('Time')
    plt.ylabel('EE force')
    plt.legend()

    plt.subplot(2, 2, 4)
    # plt.figure(4)
    plt.plot(t, h_x, '-r', label='h_x')
    plt.plot(t, h_y, '-b', label='h_y')
    plt.plot(t, h_z, '-k', label='h_z')
    plt.xlabel('Time')
    plt.ylabel('Human force')
    plt.legend()

    plt.figure(2)
    plt.subplot(2, 2, 1)
    plt.plot(t, euler_x, '-r', label='euler_x')
    plt.plot(t, euler_y, '-b', label='euler_y')
    plt.plot(t, euler_z, '-k', label='euler_z')
    plt.plot(t, euler_x_d, '--r', label='euler_x_d')
    plt.plot(t, euler_y_d, '--b', label='euler_y_d')
    plt.plot(t, euler_z_d, '--k', label='euler_z_d')
    plt.xlabel('Time')
    plt.ylabel('glass orientation')
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(t, angular_vel_x, '-r', label='angular_vel_x')
    plt.plot(t, angular_vel_y, '-b', label='angular_vel_y')
    plt.plot(t, angular_vel_z, '-k', label='angular_vel_z')
    plt.xlabel('Time')
    plt.ylabel('glass angular velocity')
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(t, t_x, '-r', label='t_x')
    plt.plot(t, t_y, '-b', label='t_y')
    plt.plot(t, t_z, '-k', label='t_z')
    plt.xlabel('Time')
    plt.ylabel('EE torque')
    plt.legend()

    plt.subplot(2, 2, 4)
    # plt.figure(4)
    plt.plot(t, h_tx, '-r', label='h_tx')
    plt.plot(t, h_ty, '-b', label='h_ty')
    plt.plot(t, h_tz, '-k', label='h_tz')
    plt.xlabel('Time')
    plt.ylabel('Human torque')
    plt.legend()

    # plt.figure(3)
    # plt.plot(t, ee_pos_x, '-r', label='ee_p_x')
    # plt.plot(t, ee_pos_y, '-b', label='ee_p_y')
    # plt.plot(t, ee_pos_z, '-k', label='ee_p_z')
    # plt.xlabel('Time')
    # plt.ylabel('EE position')
    # plt.legend()

    # plt.figure(4)
    # plt.subplot(1, 2, 1)
    # plt.plot(t, linear_acc_x, '-r', label='linear_acc_x')
    # plt.plot(t, linear_acc_y, '-b', label='linear_acc_y')
    # plt.plot(t, linear_acc_z, '-k', label='linear_acc_z')
    # plt.xlabel('Time')
    # plt.ylabel('EE linear acc')
    # plt.legend()

    # plt.subplot(1, 2, 2)
    # plt.plot(t, angular_acc_x, '-r', label='angular_acc_x')
    # plt.plot(t, angular_acc_y, '-b', label='angular_acc_y')
    # plt.plot(t, angular_acc_z, '-k', label='angular_acc_z')
    # plt.xlabel('Time')
    # plt.ylabel('EE angular acc')
    # plt.legend()

    plt.show()